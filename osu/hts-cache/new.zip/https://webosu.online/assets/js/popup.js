<!doctype html>
<html>
<head>
    <title>404 | webosu!</title>
    <link rel=”canonical” href=”https://webosu.online/”/>
    <meta name="description" content="The unofficial web port of the rhythm game osu! using chimu.moe">
    <link rel="icon" href="assets/img/favicon.png">
    <link rel="stylesheet" href="assets/css/picnic.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font.css">
    <script async src="https://arc.io/widget.min.js#iG7WX6p8"></script>
    <script defer data-domain="webosu.online" src="https://plausible.io/js/plausible.js"></script>
</head>
<body>
    <!--Nav Bar-->
    <nav id="main-nav">
        <div class="nav-link">
            <a href="index.html" class="brand">webosu!</a>
            <a href="new.html" class="pseudo button">New</a>
            <a href="hot.html" class="pseudo button">Popular</a>
            <a href="browse.html" class="pseudo button">Browse</a>
        </div>
        <div class="nav-search">
            <form action="search.html">
                <container id="searchbar" class="searchbar">
                    <input type="text" name="q" placeholder="Beatmap or SID" />
                </container>
            </form>
        </div>
        <div class="nav-tool">
            <a href="faq.html" class="pseudo button">FAQ</a>
            <a href="local.html" class="pseudo button">Favorites</a>
            <a href="settings.html" class="pseudo button">Settings</a>
            <a onclick="document.documentElement.requestFullscreen();" class="pseudo button">Fullscreen</a>
        </div>
    </nav>
    <!--Main page-->
    <div class="main-page" id="main-page">
        <div class="main-content">
            <div class="announcement">
                Notice: If you live in a Asian country and beatmaps are not loading, please use a VPN such as <a href="https://protonvpn.com/pricing">ProtonVPN</a>
            </div>
            <br>
            <div class="index-area">
                <h2>The page you are looking for doesn't exist. Check the URL for typos or click the webosu! button to go home.</h2>
            <!--Footer-->
            <footer>
            <div class="footer">
                <div class="footer-infos">
                    <span class="footer-info">Join the <a href="https://discord.gg/gHgcR92QMy">Discord server</a>!</span>
                    <span class="footer-info">Beatmap API: <a href="https://chimu.moe/">Chimu.moe</a></span>
                    <span class="footer-info">Stable Release: <a href="https://github.com/BlaNKtext/webosu">2.7.8</span>
                </div>
            </div>
        </footer>
            </div>
        </div>
</body>
<script type="module">
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.2/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.0.2/firebase-analytics.js";
  const firebaseConfig = {
    apiKey: "AIzaSyBJyrBf03GhNZbupO6uU-wtDTfAC_zY8_0",
    authDomain: "webosu.firebaseapp.com",
    projectId: "webosu",
    storageBucket: "webosu.appspot.com",
    messagingSenderId: "138250997417",
    appId: "1:138250997417:web:be7407c18de702880763b8",
    measurementId: "G-55J58MR5ZW"
  };
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>
</html>